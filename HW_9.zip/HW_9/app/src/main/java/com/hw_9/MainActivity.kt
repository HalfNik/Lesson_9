package com.hw_9

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val textList = listOf(getText("Привет!"),getText("Hallo!"),
            getText("Hello!"),getText("Guten Tag!"))

        btn_counter.setOnClickListener {
        btn_counter.text = (textList.random())

        }
    }
}